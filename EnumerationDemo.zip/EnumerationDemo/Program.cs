﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumerationDemo
{
    class Program
    {
        enum months { Jan,Feb,March,April,May,June,July,August,Sept,Oct,Nov,Dec};
        static void Main(string[] args)
        {
           // months month = months.Jan;
            //month = "Swati";


        }
    }
}
