﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPCDemo
{
    class Student
    {
        int rollNo;
        string sname;
        string branch;
        char grade;
        public static int count;
        
        static Student()
        {
            Console.WriteLine("Static Constructor");
            count = 0;
        }
        //constructor to initialize object
        public Student()
        {
            Console.WriteLine("Enter Roll No");
            rollNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            sname = Console.ReadLine();
            Console.WriteLine("Enter Branch");
            branch = Console.ReadLine();
            Console.WriteLine("Enter Grade");
            grade = Convert.ToChar(Console.ReadLine());
            count++;
        }
        public Student(int rollNo, string name)
        {
            this.rollNo = rollNo;
            sname = name;
        }
        public Student(string name,string branch)
        {
            
            sname = name;
            this.branch = branch;
        }
        public Student(int rollNo,string name,string Branch,char grade)
        {
            
            this.rollNo = rollNo;//this refers to the current object
            sname = name;
            branch = Branch;
            this.grade = grade;
        }
        ~Student()
        {
            Console.WriteLine("Destructor called");
                
        }
        public void DisplayDetails()
        {
            Console.WriteLine("Student Details:");
            Console.WriteLine("Roll No:"+rollNo);
            Console.WriteLine("Name:"+sname);
            Console.WriteLine("Branch:"+branch);
            Console.WriteLine("Grade:"+grade);
            Console.WriteLine("-----------------");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Student s = new Student();//gives call to constructor
            //Console.WriteLine("S details");
            //s.DisplayDetails();
            //Student s1 = new Student();
            //Console.WriteLine("S1 details");
            //s1.DisplayDetails();
            //Student s2 = new Student();
            //Console.WriteLine("S2 details");
            //s2.DisplayDetails();
            //Console.WriteLine("Total No of students ="+Student.count);
            Student[] students = new Student[2];
            for (int i=0;i<2;i++)
            {
                students[i] = new Student();
            }
            Console.WriteLine("Display Student Array");
            for(int i=0;i<2;i++)
            {
                students[i].DisplayDetails();
            }
        }
    }
}
