﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionOverloadingDemo
{
   
    class Program
    {
        public int Add(int a,int b)
        {
            return a + b;
        }
        public float Add(float a, float b)
        {
            return (a + b);
        }
        public double Add(double a, double b, double c)
        {
            return (a + b+ c);
        }
        public void Add(char a,char b)
        {
            Console.WriteLine(a+b);
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Add('A', 'S');
            Console.WriteLine(p.Add(2,3));
            Console.WriteLine(p.Add(2.3F,4.5F));
            Console.WriteLine(p.Add(3.4,4.5,5.6));
        }
    }
}
