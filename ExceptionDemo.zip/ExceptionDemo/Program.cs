﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    class Account
    {
        public string acc_holder_name;
        public int balance;
        public  void Withdraw(int amount)
        {
            if(amount>balance)
            {
                throw new InSufficientBalanceException("You don't have sufficient balance to withdraw this amount");

            }
            else
            {
                balance = balance-amount;
                Console.WriteLine("Balance:"+balance);
            }
        }
    }
    class Program
    {
      
        static void Main(string[] args)
        {
            Account acc = new Account();
            acc.acc_holder_name = "Swati";
            acc.balance = 10000;
            Console.WriteLine("Enter the amount to withdraw");
            int amt = Convert.ToInt32(Console.ReadLine());
            try
            {
                acc.Withdraw(amt);
            }
            catch(InSufficientBalanceException e)
            {
                Console.WriteLine(e.Message);
            }
            //int a, b, c=0;
            //int[] x = { 45, 57, 78, 89, 809 };
            //Console.WriteLine("Enter any two numbers");
            //a = Convert.ToInt32(Console.ReadLine());
            //b = Convert.ToInt32(Console.ReadLine());
            //try
            //{
            //    c = a / b;
            //    Console.WriteLine("c=" + c);
            //    Console.WriteLine(x[2]);
            //}
            
            //catch (DivideByZeroException e)
            //{
            //    Console.WriteLine("Second number can not be zero");
            //    Console.WriteLine(e.Message);
            //    Console.WriteLine("c="+c);
            //}
            //catch(IndexOutOfRangeException e)
            //{
            //    Console.WriteLine(e.Message);
            //    Console.WriteLine(e.Source);
            //}

            //catch (Exception e)
            //{
            //    Console.WriteLine("Exception Ocurred");
            //}
            //finally
            //{
            //    Console.WriteLine("This is finally block");
            //}
        }
    }
}
