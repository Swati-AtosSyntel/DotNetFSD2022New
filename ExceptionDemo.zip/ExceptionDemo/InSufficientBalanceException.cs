﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    class InSufficientBalanceException:ApplicationException
    {
        public InSufficientBalanceException(string msg):base(msg)
        {

        }
    }
}
