﻿using System;


namespace ArraysDemo
{
    class Program
    {
        public void multiDimensionArrayExample()
        {
            int[,] a = new int[2, 2];
            for(int i = 0; i < 2; i++)//row loop
            {
                for (int j = 0; j < 2; j++)//column loop
                {
                    Console.WriteLine("Enter element"+i+j);
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Display multidomensional array");
            for (int i = 0; i < 2; i++)//row loop
            {
                for (int j = 0; j < 2; j++)//column loop
                {
                    Console.Write(a[i,j]+"\t");
                   
                }
                Console.WriteLine();
            }
        }
        public void JaggedArrayExample()
        {
            int[][] jarr = new int[3][];
            jarr[0] = new int[4];
            jarr[1] = new int[2];
            jarr[2] = new int[3];
            Console.WriteLine("Enter Data for each row");
            for(int i=0;i<3;i++)
            {
                
                for(int j=0;j<jarr[i].Length;j++)
                {
                    jarr[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Jagged Array Data is ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < jarr[i].Length; j++)
                {
                    Console.Write(jarr[i][j]+"\t");
                }
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
           // int? p = null;

            Program p =new Program();
            //p.multiDimensionArrayExample();
            p.JaggedArrayExample();
            //declare array to store 5 integers
            //int[] scores = new int[5];
            ////initalising array
            //scores[0] = 34;
            //scores[1] = 84;
            //scores[2] = 64;
            //scores[3] = 65;
            //scores[4] = 74;
            ////for op to initialize array
            //Console.WriteLine("Enter Data");
            //int sum = 0;
            //for(int i = 0; i < 5; i++)
            //{
            //    scores[i] = Convert.ToInt32(Console.ReadLine());

            //    sum = sum + scores[i];
            //}
            //Console.WriteLine("Display All Scores");
            //for(int i = 0; i < 5; i++)
            //{
            //    Console.Write(scores[i]+"\t");
            //}
            //Console.WriteLine("Average Score:"+(sum/5));
        }
    }
}
