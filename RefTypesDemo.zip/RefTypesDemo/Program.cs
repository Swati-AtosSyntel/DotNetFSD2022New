﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefTypesDemo
{
    class Car
    {
        public int model;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Car c = new Car();
            c.model = 2345;
            Console.WriteLine("c.model="+c.model);
            Car c1 = c;
            Console.WriteLine("c1.model="+c1.model);
            Console.WriteLine("Modify model number for c");
            c.model = 5432;
            Console.WriteLine("After modifying c.model="+c.model);
            Console.WriteLine("After modifying c.model value of c1.model=" + c1.model);
            Car c2 = new Car();
            c2.model = 3456;
            Console.WriteLine("c.model=" + c.model);
            Console.WriteLine("c1.model=" + c1.model);
            Console.WriteLine("c2.model=" + c2.model);

        }
    }
}
