﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo2
{
    interface I1
    {
        void method1();
        void method2();
    }
    interface I2
    {
        void method3();
        void method4();
    }
    class X : Animal, I1, I2
    {
        public override void MakeNoise()
        {
            
        }
        public new void method1()
        {
           
        }

        public void method2()
        {
            
        }

        public void method3()
        {
            
        }

        public void method4()
        {
            
        }
    }
    abstract class Animal
    {
        public static void method1()
        {

        }
        public abstract void MakeNoise();
    }
    class Dog : Animal
    {
        public override void MakeNoise()
        {
            Console.WriteLine("Dog is making noise");
        }
    }
    class Cat : Animal
    {
        public override void MakeNoise()
        {
            Console.WriteLine("Cat is making noise");
        }
    }
    class Horse : Animal
    {
        public override void MakeNoise()
        {
            Console.WriteLine("Horse is making noise");
        }
    }
    sealed class A
    {

    }
    
    class Program
    {
        public static void callMakeNoiseMethod(Animal a)
        {
            a.MakeNoise();
        }
        static void Main(string[] args)
        {
            Animal[] animals = { new Dog(), new Cat(), new Horse(), new Cat() };

            foreach(Animal animal in animals)
            {
                callMakeNoiseMethod(animal);
            }

            

        }
    }
}
