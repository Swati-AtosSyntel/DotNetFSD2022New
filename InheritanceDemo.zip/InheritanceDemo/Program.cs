﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    public class Employee
    {
        public int id;
        public string name;
        public string department;
        public string location;

        public Employee()
        {
            Console.WriteLine("Employee Class Constructor");
            Console.WriteLine("Enter id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Department Name");
            department = Console.ReadLine();
            Console.WriteLine("Enter Location");
            location = Console.ReadLine();

        }
        public virtual void calcSalary()
        {
            Console.WriteLine("Employee calcSalary method");
        }
        public virtual void displayDetails()
        {
            Console.WriteLine(id);
            Console.WriteLine(name);
            Console.WriteLine(department);
            Console.WriteLine(location);
                
        }

    }
    public class Trainer : Employee
    {
        int no_of_batches;
        int participants;
        int certifications;
        string[] upgradations;

        public Trainer()
        {
            Console.WriteLine("Trainer Class Constructor");
            Console.WriteLine("Enter total number of batches taken");
            no_of_batches = Convert.ToInt32(Console.ReadLine());

        }
        public override void calcSalary()
        {
            Console.WriteLine("Trainer calcSalary method");
            //base.calcSalary();
        }
        public override void displayDetails()
        {
            base.displayDetails();
            Console.WriteLine(no_of_batches);
        }
    }
    public class campusHireHead : Employee
    {
        public override void calcSalary()
        {
            Console.WriteLine("campusHireHead calcSalary method");
        }
        
    }
    class Program
    {
        public static void callCalcSalaryMethod(Employee e)
        {
            e.calcSalary();
            
        }
        static void Main(string[] args)
        {


            //Employee[] employees = { new Trainer(), new campusHireHead(), new Trainer() };
            //foreach(Employee emp in employees)
            //{
            //    callCalcSalaryMethod(emp);
            //}

            Trainer t = new Trainer();//class super class constructor and then sublcass constructor
            t.displayDetails();

        }
    }
}
